﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Windows.Forms;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace projbm
{
    public partial class applyLoan : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand com;

        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            if (!IsPostBack)
            {
                MultiViewloan.ActiveViewIndex = 0;
            }
            if (dd_loanType.Text == "Home/Personal")
            {
                txtroi.Text = "12%";
            }
            else
            {
                txtroi.Text = "10%";

            }

           //CompareValidator1.ValueToCompare = DateTime.Now.ToShortDateString(); // for loan issue date
            Txtloanapply.Text = DateTime.Today.ToShortDateString(); // for loan apply date

        }

        protected void MultiView1_ActiveViewChanged(object sender, EventArgs e)
        {

        }

        protected void img_loansub_Click(object sender, ImageClickEventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["TB"].ConnectionString;
            con = new SqlConnection(constr);


            try
            {
                string Loan;
                con.Open();
                com = new SqlCommand("sp_loan1", con);
                com.CommandType = System.Data.CommandType.StoredProcedure;

                com.Parameters.AddWithValue("@loantype", dd_loanType.Text);
                com.Parameters.AddWithValue("@loanamt", txtloanamt.Text);
                com.Parameters.AddWithValue("@appdate", Txtloanapply.Text);
                com.Parameters.AddWithValue("@issuedate", txtLoanIssue.Text);
                com.Parameters.AddWithValue("@roi", txtroi.Text);
                com.Parameters.AddWithValue("@duration", ddloanduration.Text);
                
                Random l = new Random();
                Loan = "L-" + (Convert.ToString(l.Next(100, 999)));
                MessageBox.Show("Your Login ID is:" + Loan);

                com.Parameters.AddWithValue("@loanid", Loan);
                com.ExecuteNonQuery();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }




            if (dd_loanType.Text == "Home/Personal")
            {
                MultiViewloan.ActiveViewIndex = 1;
            }
            else
            {
                MultiViewloan.ActiveViewIndex = 2;

            }
            }

        protected void dd_loanType_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void lnamnt_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Personal_sub_Click(object sender, ImageClickEventArgs e) //Educational
        {
        }

        protected void Personal_Click(object sender, ImageClickEventArgs e) //Personal
        {
            
        }

        protected void txtLoanIssue_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtroi_TextChanged(object sender, EventArgs e)
        {

        }

        protected void txtloanamt_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["TB"].ConnectionString;
            con = new SqlConnection(constr);


            try
            {

                con.Open();
                com = new SqlCommand("sp_personal1", con);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@annual", txt_perloan_anincom.Text);
                com.Parameters.AddWithValue("@companyname", txt_perloan_compnam.Text);
                com.Parameters.AddWithValue("@designation", txt_perloan_desig.Text);
                com.Parameters.AddWithValue("@totalexp", txt_perloan_totexp.Text);
                com.Parameters.AddWithValue("@currentexp", txt_perloan_cuexp.Text);
                com.ExecuteNonQuery();
                MessageBox.Show("Personal Loan applied successfully");
                Response.Redirect("loginhome.aspx", false);



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        protected void ImageButton1_Click1(object sender, ImageClickEventArgs e)
        {

            string constr = ConfigurationManager.ConnectionStrings["TB"].ConnectionString;
            con = new SqlConnection(constr);


            try
            {

                con.Open();
                com = new SqlCommand("sp_education1", con);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@course", course.Text);
                com.Parameters.AddWithValue("@coursetype", dd_coursetype.Text);
                com.Parameters.AddWithValue("@father", father.Text);
                com.Parameters.AddWithValue("@fatheroccu", ddfatheroccu.Text);
                com.Parameters.AddWithValue("@fathertotexp", fathertotexp.Text);
                com.Parameters.AddWithValue("@fathercurrexp", fathercurrexp.Text);
                com.Parameters.AddWithValue("@ratcardno", ratcardno.Text);
                com.Parameters.AddWithValue("@annualin", annualin.Text);
                com.ExecuteNonQuery();
                MessageBox.Show("Educational Loan applied successfully");
                Response.Redirect("loginhome.aspx", false);



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }


        }
    }
}