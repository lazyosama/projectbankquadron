﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace projbm
{
    public partial class AdminLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        // For Admin Login check admin username and admin password.

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)           
        {
            String username = txtUsername.Text;
            string password = txtPassword.Text;

            if (username == "admin" && password == "admin123")
            {
                Server.Transfer("login.aspx");
            }
            else
            {
                MessageBox.Show("Invalid Username or Password");
            } 

        
    }

        protected void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }
