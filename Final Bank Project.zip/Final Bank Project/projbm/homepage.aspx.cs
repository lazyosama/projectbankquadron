﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace projbm
{
    public partial class homepage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Literal marquee = new Literal();
            marquee.Text = "<marquee style=color:#663300; font-weight:700; font-size:large; width:877px; height:22px; margin-top:0px; position:middle; top:-3px; left:-73px; margin-left:0px;> Welcome to Iron Bank </marquee>";
            this.Controls.Add(marquee);
        }

       

        protected void admin_Click(object sender, ImageClickEventArgs e)
        {
            Server.Transfer("AdminLogin.aspx");
        }

        protected void ImgCustomer_Click(object sender, ImageClickEventArgs e)
        {
            Server.Transfer("login.aspx");
        }

        protected void ImgAboutus_Click(object sender, ImageClickEventArgs e)
        {
            Server.Transfer("aboutus.aspx");
        }

        protected void ImgContact_Click(object sender, ImageClickEventArgs e)
        {
            Server.Transfer("contactus.aspx");
        }
    }
}