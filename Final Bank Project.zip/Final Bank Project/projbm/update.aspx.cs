﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Windows.Forms;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace projbm
{
    public partial class update : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand com;
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
        }

        protected void Button1_Click(object sender, System.EventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["TB"].ConnectionString;
            con = new SqlConnection(constr);

            try
            {

                con.Open();
                com = new SqlCommand("sp_Update1", con);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@custID", custID.Text);
                com.Parameters.AddWithValue("@name", name.Text);
                com.Parameters.AddWithValue("@uname", uname.Text);
                com.Parameters.AddWithValue("@add", add.Text);
                com.Parameters.AddWithValue("@email", email.Text);
                com.Parameters.AddWithValue("@mstatus", ddmstatus.Text);
                com.Parameters.AddWithValue("@idn", idn.Text);
                com.Parameters.AddWithValue("@pass", pass.Text);
                com.Parameters.AddWithValue("@repass", repass.Text);

                com.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
        }
    }
}