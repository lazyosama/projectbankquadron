﻿//using iTextSharp.text;
//using iTextSharp.text.html;
//using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;



namespace projbm
{
    public partial class bankstatement : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            Session["date1"] = txt_frmdt.Text;
            Session["date2"] = txt_todt.Text; 

        }

        protected void Bttnbnkstview_Click(object sender, EventArgs e)
        {
            Response.Redirect("bank statement grid.aspx");
        }

       

    }
}