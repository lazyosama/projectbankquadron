﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Windows.Forms;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace projbm
{

    public partial class transaction : System.Web.UI.Page
    {
        int balance;
        SqlConnection con;
        SqlCommand com;
         string indeposite="";
       

        protected void Page_Load(object sender, EventArgs e)
        {
            tdate.Text = DateTime.Today.ToShortDateString();

            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            string a = Session["ID"].ToString();
            string constr = ConfigurationManager.ConnectionStrings["TB"].ConnectionString;
            con = new SqlConnection(constr);
            //SqlConnection Conn = new SqlConnection("Data Source=PC269446;Initial Catalog=TB;Persist Security Info=True;User ID=sa;Password=Password123");
            //Conn.Open();
            con.Open();
            SqlCommand Comm1 = new SqlCommand("select customer_ID from customer_details11 where username='" + Session["ID"] + "'", con);
            custID.Text = Comm1.ExecuteScalar().ToString();
            string s = Comm1.ExecuteScalar().ToString();

            SqlCommand Comm2 = new SqlCommand("select acctype from customer_details11 where username='" + Session["ID"] + "'", con);
            acctype.Text = Comm2.ExecuteScalar().ToString();

            SqlCommand Comm3 = new SqlCommand("select accnum from customer_details11 where username='" + Session["ID"] + "'", con);
            accno.Text = Comm3.ExecuteScalar().ToString();

            SqlCommand Comm4 = new SqlCommand("select balance_amount from account_detail100 where customer_ID='" + s + "'", con);
            indeposite = Comm4.ExecuteScalar().ToString();
            balance = Convert.ToInt32(indeposite);

            con.Close();



        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {


        }

        protected void Imgbut_submit_Click(object sender, ImageClickEventArgs e)
        {
            
            string tranid = "";
            string constr = ConfigurationManager.ConnectionStrings["TB"].ConnectionString;
            con = new SqlConnection(constr);
            

           
            
            try
            {
                if (ddttype.Text == "Debit")
                {

                    if (Convert.ToInt32(tamount.Text) < balance)
                    {

                        con.Open();
                        balance = balance - (Convert.ToInt32(tamount.Text));

                        com = new SqlCommand("sp_updateBalance1", con);
                        com.CommandType = System.Data.CommandType.StoredProcedure;

                        com.Parameters.AddWithValue("@bal", balance);
                        com.Parameters.AddWithValue("@cust_id", custID.Text.Trim());
                        com.ExecuteNonQuery();
                       // MessageBox.Show(Convert.ToString(balance));
                        com = new SqlCommand("sp_transact3", con);
                        com.CommandType = System.Data.CommandType.StoredProcedure;
                        com.Parameters.AddWithValue("@custID", custID.Text);
                        com.Parameters.AddWithValue("@accno", accno.Text);
                        com.Parameters.AddWithValue("@acctype", acctype.Text);
                        com.Parameters.AddWithValue("@trantype", ddttype.Text);
                        com.Parameters.AddWithValue("@trandate", tdate.Text);
                        com.Parameters.AddWithValue("@amt", tamount.Text);


                        Random t = new Random();
                        tranid = "T-" + (Convert.ToString(t.Next(10, 99)));
                        MessageBox.Show("Your Transaction ID is:" + tranid);
                        com.Parameters.AddWithValue("@tranID", tranid);



                        com.ExecuteNonQuery();
                       // con.Close();
                       // Response.Redirect("loginhome.aspx", false);


                    }

                    else
                    {
                        MessageBox.Show("Insufficient Balance");
                    }
                }
               // else if (ddttype.Text == "Debit")
                else
                {
                    con.Open();
                    balance = balance + (Convert.ToInt32(tamount.Text));

                    com = new SqlCommand("sp_updateBalance1", con);
                    com.CommandType = System.Data.CommandType.StoredProcedure;

                    com.Parameters.AddWithValue("@bal", balance);
                    com.Parameters.AddWithValue("@cust_id", custID.Text.Trim());
                    com.ExecuteNonQuery();
                    //MessageBox.Show(Convert.ToString(balance));

                    com = new SqlCommand("sp_transact3", con);
                    com.CommandType = System.Data.CommandType.StoredProcedure;
                    com.Parameters.AddWithValue("@custID", custID.Text);
                    com.Parameters.AddWithValue("@accno", accno.Text);
                    com.Parameters.AddWithValue("@acctype", acctype.Text);
                    com.Parameters.AddWithValue("@trantype", ddttype.Text);
                    com.Parameters.AddWithValue("@trandate", tdate.Text);
                    com.Parameters.AddWithValue("@amt", tamount.Text);


                    Random t = new Random();
                    tranid = "T-" + (Convert.ToString(t.Next(10, 99)));
                    MessageBox.Show("Your Transaction ID is:" + tranid);
                    com.Parameters.AddWithValue("@tranID", tranid);



                    com.ExecuteNonQuery();

                }
                //else
                //{
                //    Response.Redirect("transaction.aspx");
                //}

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            Response.Redirect("loginhome.aspx", false);     
        
            }
        }
    }
