﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration; //Provides access to configuration files for client applications.
using System.Windows.Forms;  //Dialog box
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;


namespace projbm
{
    public partial class registration : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand com;
        SqlCommand com2;

        
        // For Selecting the country from drop down list

        public void Bind_ddlCountry()
        {
            //Provides access to configuration files for client applications. 

            string constr = ConfigurationManager.ConnectionStrings["TB"].ConnectionString;
            con = new SqlConnection(constr);
            try
            {
                con.Open();
                SqlCommand com = new SqlCommand("Select country_id,country_name from country", con);
                SqlDataReader dr = com.ExecuteReader();
                ddCountry.DataSource = dr;
                ddCountry.Items.Clear();
                ddCountry.Items.Add("Please select item");
                ddCountry.DataTextField = "country_name";
                ddCountry.DataValueField = "country_id";
                ddCountry.DataBind();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }


        //For selecting the states from drop down list based on selected country

        public void Bind_ddlstate()
        {
            string constr = ConfigurationManager.ConnectionStrings["TB"].ConnectionString;
            con = new SqlConnection(constr);
            try
            {
                con.Open();
                SqlCommand com = new SqlCommand("Select state_id,state_name from state1 where country_id='" + ddCountry.SelectedValue + "'", con);
                SqlDataReader dr = com.ExecuteReader();
                ddstate.DataSource = dr;
                ddstate.Items.Clear();
                ddstate.Items.Add("Please select item");
                ddstate.DataTextField = "state_name"; 
                ddstate.DataValueField = "state_id";
                ddstate.DataBind();  //Binds a data source to the invoked server control and all its child controls.

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

        }








        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None;
            if (!IsPostBack)
            {
                Bind_ddlCountry();
            }

           
            CompareValidator1.ValueToCompare = DateTime.Now.ToShortDateString(); // for dob comparision
            TxtregDate.Text = DateTime.Today.ToShortDateString(); // for reg date



        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            string loginn;
            string AccountNo;
            string constr = ConfigurationManager.ConnectionStrings["TB"].ConnectionString;
            con = new SqlConnection(constr);

            //For selecting the gender

            string gender = string.Empty;
            if (Rbl.SelectedIndex == 1)
            {
                gender = "Male";
            }
            else
            {
                gender = "Female";
            }

            //Selecting account type

            string acctype = "";
            if (Salary.Checked == true)
            {
                acctype = "Salary";
            }
            else
            {
                acctype = "Saving";
            }
            //Reading value of checked radiobutton
            
            //displaying error message if no radio button selected
            
            
             try
            {
               // Opening Connection and adding values data to database
                con.Open();
                com = new SqlCommand("sp_Cust10", con);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@name", Txtname.Text);
                com.Parameters.AddWithValue("@uname",Txtusername.Text);
                 com.Parameters.AddWithValue("@pass",Txtrepassword.Text);
                 com.Parameters.AddWithValue("@repass",Txtrepassword.Text);
                 com.Parameters.AddWithValue("@gdtype",ddgudType.Text);
                 com.Parameters.AddWithValue("@gdname",Txtgardian.Text);
                 com.Parameters.AddWithValue("@add",Txtaddress.Text);

                 com.Parameters.AddWithValue("@country", ddCountry.SelectedValue);
                 com.Parameters.AddWithValue("@state",ddstate.Text);
                 com.Parameters.AddWithValue("@email",Txtemail.Text);
                 com.Parameters.AddWithValue("@gender",gender);
                 com.Parameters.AddWithValue("@mstatus",ddMaritalStatus.Text);
                 com.Parameters.AddWithValue("@cnum",Txtcontact.Text);
                 com.Parameters.AddWithValue("@dob",Txtdob.Text);
                 com.Parameters.AddWithValue("@rdate", TxtregDate.Text);
                 com.Parameters.AddWithValue("@acctype",acctype);
                 com.Parameters.AddWithValue("@bname",Txtbranch.Text);
                 com.Parameters.AddWithValue("@cstatus", TextBoxCitizenStatus.Text);
                 com.Parameters.AddWithValue("@initdeposit", TextBoxInitialDeposit.Text);
                 com.Parameters.AddWithValue("@ipt",ddidType.Text);
                 com.Parameters.AddWithValue("@idn",Txtidno.Text);
                 com.Parameters.AddWithValue("@raccname",Txtrefname.Text);
                 com.Parameters.AddWithValue("@raccno",Txtrefaccno.Text);
                 com.Parameters.AddWithValue("@raccadd",Txtrefaddress.Text);
                //com.ExecuteNonQuery();
                Response.Redirect("homepage.aspx", false);

                Random r = new Random();
                loginn = "R-" + (Convert.ToString(r.Next(100, 999)));
                MessageBox.Show("Your Login ID is:" + loginn);


                Random acc = new Random();
                AccountNo = Convert.ToString(acc.Next(0, 999999999));
                MessageBox.Show("Your Acc no is:" + AccountNo);

                com.Parameters.AddWithValue("@custID",loginn);
                com.Parameters.AddWithValue("@accno", AccountNo);

               // com.ExecuteNonQuery();



                com2 = new SqlCommand("sp_accdetails100", con);
               com2.CommandType = System.Data.CommandType.StoredProcedure;
               com2.Parameters.AddWithValue("@custID", loginn);
               com2.Parameters.AddWithValue("@balanceamt", TextBoxInitialDeposit.Text);
               com2.Parameters.AddWithValue("@accnum ", AccountNo);
               com2.Parameters.AddWithValue("@acctype ", acctype);

               com.ExecuteNonQuery();
               com2.ExecuteNonQuery();

               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }
            //Server.Transfer("homepage.aspx");

        }
            

        protected void ddstate_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
        }

        protected void ddCountray_SelectedIndexChanged(object sender, EventArgs e)
        {
            Bind_ddlstate();
        }

        protected void rbMale_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void RadioButtonList2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            Txtname.Text = "";
            Txtusername.Text = "";
            Txtpassword.Text = "";
            Txtrepassword.Text = "";
            Txtemail.Text = "";
           Txtcontact.Text = "";
            Txtaddress.Text = "";
            Txtgardian.Text = "";
            
            Txtemail.Text = "";
            Txtdob.Text = "";
            Txtbranch.Text = "";
            TextBoxInitialDeposit.Text = "";
            Txtidno.Text = "";
            Txtrefaccno.Text = "";
            Txtrefname.Text = "";
            Txtrefaddress.Text = "";

            ddgudType.Items.Clear();
            ddCountry.Items.Clear();
            
            ddMaritalStatus.Items.Clear();
            ddstate.Items.Clear();
            TextBoxCitizenStatus.Text="";
            ddidType.Items.Clear();
         
            Rbl.SelectedIndex = -1;
            Txtname.Focus();

        }

        protected void Savings_CheckedChanged(object sender, EventArgs e)
        {
            TextBoxInitialDeposit.Enabled = false;
            if (ddCountry.SelectedValue == "101" && Savings.Checked == true)
            {
                TextBoxInitialDeposit.Text = "5000";
            }

            else if (ddCountry.SelectedValue == "102" && Savings.Checked == true)
            {
                TextBoxInitialDeposit.Text = "15000";
            }

            else if (ddCountry.SelectedValue == "103" && Savings.Checked == true)
            {
                TextBoxInitialDeposit.Text = "14000";
            }

        }

        protected void Salary_CheckedChanged(object sender, EventArgs e)
        {
            TextBoxInitialDeposit.Enabled = false;
            if (ddCountry.SelectedValue == "101" && Salary.Checked == true)
            {

                TextBoxInitialDeposit.Text = "0";
            }

            else if (ddCountry.SelectedValue == "102" && Salary.Checked == true)
            {

                TextBoxInitialDeposit.Text = "0";
            }

            if (ddCountry.SelectedValue == "103" && Salary.Checked == true)
            {

                TextBoxInitialDeposit.Text = "0";
            }
        }

        protected void Rbl_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Txtdob_TextChanged(object sender, EventArgs e)
        {
            int age;
            age = System.DateTime.Today.Year - Convert.ToDateTime(Txtdob.Text).Year;

            if (age < 18)
            {
                TextBoxCitizenStatus.Text = "Minor";
            }

            else if (age > 18 && age <= 60)
            {
                TextBoxCitizenStatus.Text = "Normal";
            }

            else
            {
                TextBoxCitizenStatus.Text = "Senior";
            }
            TextBoxCitizenStatus.Enabled = true;
        }

        

        

       

        
        }
    }

