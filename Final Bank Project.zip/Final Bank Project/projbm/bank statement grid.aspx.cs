﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace projbm
{
    public partial class bank_statement_grid : System.Web.UI.Page
    {
        string date1, date2;
       
       

        protected void Page_Load(object sender, EventArgs e)
        {
             date1 = Session["date1"].ToString();
             date2 = Session["date2"].ToString();
            if (!this.IsPostBack)
            {
                this.BindGrid();
            }
        }
        public void BindGrid()
        {
            string constr = ConfigurationManager.ConnectionStrings["TB"].ConnectionString;
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            DataSet ds = new DataSet();
            DataTable FromTable = new DataTable();
            SqlCommand Comm1 = new SqlCommand("select customer_ID from customer_details11 where username='" + Session["ID"] + "'", con);           
            string r = Comm1.ExecuteScalar().ToString();
           // MessageBox.Show(r.ToString());
            //MessageBox.Show(date1.ToString());
           // MessageBox.Show(date2.ToString());
      		
            SqlDataAdapter adp = new SqlDataAdapter("select * from transaction_details4 where customer_ID='" + r + "' and transaction_date BETWEEN '" + date1 + "' AND '" + date2 + "' ", con);
            adp.Fill(ds);
                       
                            FromTable = ds.Tables[0];
                            if (FromTable.Rows.Count > 0)
                            {
                                GridView2.DataSource = FromTable;
                                GridView2.DataBind();
                               
                            }
                            else
                            {
                                FromTable.Rows.Add(FromTable.NewRow());
                                GridView2.DataSource = FromTable;
                                GridView2.DataBind();
                                int TotalColumns = GridView2.Rows[0].Cells.Count;
                                GridView2.Rows[0].Cells.Clear();
                                GridView2.Rows[0].Cells.Add(new TableCell());
                                GridView2.Rows[0].Cells[0].ColumnSpan = TotalColumns;
                                GridView2.Rows[0].Cells[0].Text = "No records Found";
                            }
                            ds.Dispose();
                            con.Close();
            
        }
        protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindGrid();
        }
    }
}