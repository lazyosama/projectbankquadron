﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Windows.Forms;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace projbm
{
    public partial class login : System.Web.UI.Page
    {
        SqlConnection con;
        SqlCommand com;
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Imglogin_Click(object sender, ImageClickEventArgs e)
        {
            //Server.Transfer("loginhome.aspx");
            
         
        }

        protected void Imglogin_Click1(object sender, ImageClickEventArgs e)
        {
            string constr = ConfigurationManager.ConnectionStrings["TB"].ConnectionString;
            con = new SqlConnection(constr);


            try
            {
                con.Open();
                com = new SqlCommand("sp_login1", con);
                com.CommandType = System.Data.CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@uname", TxtUsername.Text);
                com.Parameters.AddWithValue("@pass", TxtPassword.Text);
                com.ExecuteNonQuery();
                //com.Connection = con;
                SqlDataAdapter da = new SqlDataAdapter(com);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    Session["ID"] = TxtUsername.Text;
                    Response.Redirect("~\\loginhome.aspx", false);
                    MessageBox.Show("Login Successfull");
                    
                }
                else
                {
                    MessageBox.Show("Invalid username or password");
                }

                con.Close();
                //Response.Redirect("~\\loginhome.aspx", false);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con.Close();
            }

            //Response.Redirect("loginhome.aspx",false);
        }


        
    }
}